require("./test1.js")
require("./test2.js")
require("./test3.js")
require("./test4.js")