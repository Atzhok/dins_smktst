const Nightmare = require("nightmare"); 
const fs = require("fs");
const process = require("process");
const nightmare = Nightmare({show: true, height: 720, width: 1280})


nightmare
 .goto("https://jsonplaceholder.typicode.com/posts?userId=1&title=qui%20est%20esse")
 .screenshot("./test1.png")
 .end()
 .then(function(result) {
    console.log("Test 1 Succeeded");
  })
  .catch(function(result) {
    console.log("Test 1 Failed");
  })