const Nightmare = require("nightmare"); 
const fs = require("fs");
const process = require("process");
const nightmare = Nightmare({show: true, height: 720, width: 1280})


nightmare
 .goto("https://example.com1")
 .screenshot("./test2.png")
 .end()
 .then(function(result) {
    console.log("Test 2 Succeeded");
  })
  .catch(function(result) {
    console.log("Test 2 Failed");
  })