const Nightmare = require("nightmare"); 
const fs = require("fs");
const process = require("process");
const nightmare = Nightmare({show: true, height: 720, width: 1280})
const userId = process.env.USERID ? `userId=${process.env.USERID}` : '';
const title = process.env.TITLE ? `title=${process.env.TITLE}` : '';


console.log(`Initiating test with ${userId} & ${title}`)
nightmare
 .goto(`https://jsonplaceholder.typicode.com/posts?${userId}&${title}`)
 .screenshot("./test3.png")
 .end()
 .then(function(result) {
    console.log("Test 3 Succeeded");
  })
  .catch(function(result) {
    console.log("Test 3 Failed");
  })