const Nightmare = require("nightmare"); 
const fs = require("fs");
const process = require("process");
const { endianness } = require("os");
const nightmare = Nightmare({show: true, height: 720, width: 1280})


nightmare
 .goto("https://jsonplaceholder.typicode.com/posts?userId=1&title=qui%20est%20esse")
 .screenshot("./test4.png")
 .evaluate(function(){
    return document.body.innerText;
  })
  .end()
 .then(function(body) {
    const result = JSON.parse(body);
    if (result[0].userId !== 1) {
      throw "Wrong user id";
    }
    if (Number.parseInt(result[0].id) == NaN) {
      throw "Id is not number";
    }
    if (Object.keys(result[0]).length != 4) {
      throw "Unexpected keys in object";
    }
    if (result[0].title !== "qui est esse") {
      throw "Wrong title";
    }
    console.log("Test 4 Succeeded");
  })
  .catch(function(result) {
    console.log("Test 4 Failed", result);
  })